﻿configuration CreateADPDC 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature 'ADDSInstall' { 
            Name = "AD-Domain-Services" 
        }

        xADDomain FirstDC
        {
            DomainName                    = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn                     = "[WindowsFeature]ADDSInstall"
        } 

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
} 

configuration JoinAD 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, xActiveDirectory, xDSCDomainJoin
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WaitForAll DC
	    {
		    ResourceName      = '[xADDomain]FirstDC'
		    NodeName          = 'DC1'
		    RetryIntervalSec  = 15
		    RetryCount        = 30
        }
        
        xDSCDomainJoin "Join$Domain"
        {
            Domain     = $DomainName
            Credential = $DomainCreds
            DependsOn  ='[WaitForAll]DC'
        }

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
} 